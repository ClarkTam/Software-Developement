import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.input.KeyCode;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.geometry.Pos;
import javafx.scene.layout.BorderPane; 

public class BounceBallControl extends Application {
    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
        BallPane ballPane = new BallPane(); // Create a ball pane
        
        HBox hBox = new HBox();
        hBox.setSpacing(10);
        hBox.setAlignment(Pos.CENTER);
        Button btUP = new Button("UP");
        Button btDOWN = new Button("DOWN");
        Button btLEFT = new Button("LEFT");
        Button btRIGHT = new Button("RIGHT");
        hBox.getChildren().add(btUP);
        hBox.getChildren().add(btDOWN);
        hBox.getChildren().add(btLEFT);
        hBox.getChildren().add(btRIGHT);
        BorderPane borderPane = new BorderPane();
        borderPane.setCenter(ballPane);
        borderPane.setBottom(hBox);
        BorderPane.setAlignment(hBox, Pos.CENTER);

        btUP.setOnAction(e -> {
            ballPane.moveUP();
        });
        btDOWN.setOnAction(e -> {
            ballPane.moveDOWN();
        });
        btLEFT.setOnAction(e -> {
            ballPane.moveLEFT();
        });
        btRIGHT.setOnAction(e -> {
            ballPane.moveRIGHT();
        });


        // Pause and resume animation
        ballPane.setOnMousePressed(e -> ballPane.pause());
        ballPane.setOnMouseReleased(e -> ballPane.play());
        
        /* 
        // Increase and decrease animation
        ballPane.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.UP) {
                ballPane.increaseSpeed();
            }else if (e.getCode() == KeyCode.DOWN) {
                ballPane.decreaseSpeed();
            }
        });
        */

        ballPane.setOnKeyPressed(e -> {
            if (e.getCode() == KeyCode.UP) {
                ballPane.play();
                ballPane.moveUP();
            }else if (e.getCode() == KeyCode.DOWN) {
                ballPane.play();
                ballPane.moveDOWN();
            }else if (e.getCode() == KeyCode.LEFT) {
                ballPane.play();
                ballPane.moveLEFT();
            }else if (e.getCode() == KeyCode.RIGHT) {
                ballPane.play();
                ballPane.moveRIGHT();
            }
        });

        // Create a scene and place it in the stage
        Scene scene = new Scene(borderPane, 250, 150);
        primaryStage.setTitle("BounceBallControl"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
        
        // Must request focus after the primary stage is displayed
        ballPane.requestFocus();
    }
    public static void main (String[]args){
        launch(args);
    }
}
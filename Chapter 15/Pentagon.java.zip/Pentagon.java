import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.shape.Polygon;
import javafx.animation.Timeline;
import javafx.animation.FadeTransition;
import javafx.animation.PathTransition;
import javafx.util.Duration;

public class Pentagon extends Application {
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {   
		// Create a scene and place it in the stage
		StackPane pane = new StackPane();
		Scene scene = new Scene(pane, 400, 400);
		primaryStage.setTitle("ShowPolygon"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage

		Polygon polygon = new Polygon();
		polygon.setFill(Color.WHITE);
		polygon.setStroke(Color.BLACK);

		ObservableList<Double> list = polygon.getPoints();
		
		double centerX = pane.getWidth() / 2, centerY = pane.getHeight() / 2;
		double radius = Math.min(pane.getWidth(), pane.getHeight()) * 0.4;

		// s represents the number of sides of the shape
		// Make sure to update this number when necessary
		int s = 5;
		// Add points to the polygon list
		for (int i = 0; i < s; i++) {
			list.add(centerX + radius * Math.cos(2 * i * Math.PI / s)); 
			list.add(centerY - radius * Math.sin(2 * i * Math.PI / s));
		}     
		polygon.setRotate(54.5);
		pane.getChildren().clear();
		pane.getChildren().add(polygon); 
		
		Polygon rectangle = new Polygon();
		ObservableList<Double> list2 = rectangle.getPoints();
		rectangle.setFill(Color.RED);
		rectangle.setStroke(Color.GREY);
		
		centerX = pane.getWidth() / 2;
		centerY = pane.getHeight() / 2;
		radius = Math.min(pane.getWidth(), pane.getHeight()) * 0.1;
		
		// s represents the number of sides of the shape
		// Make sure to update this number when necessary
		s = 4;
		// Add points to the polygon list
		for (int i = 0; i < s; i++) {
			list2.add(centerX + radius * Math.cos(2 * i * Math.PI / s)); 
			list2.add(centerY - radius * Math.sin(2 * i * Math.PI / s));
		}     
		rectangle.setRotate(45);
		pane.getChildren().add(rectangle); 


		FadeTransition ft =
        new FadeTransition(Duration.millis(5000), rectangle);
		ft.setFromValue(1.0);
		ft.setToValue(0.1);
		ft.setCycleCount(Timeline.INDEFINITE);
		ft.setAutoReverse(true);
		ft.play();
		rectangle.setOnMousePressed(e -> ft.pause());
		rectangle.setOnMouseReleased(e -> ft.play());

		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.millis(5000));
		pt.setPath(polygon);
		pt.setNode(rectangle);
		pt.setOrientation(PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
		pt.setCycleCount(Timeline.INDEFINITE);
		pt.setAutoReverse(false);
		pt.play(); // Start animation 
		polygon.setOnMousePressed(e -> pt.pause());
		polygon.setOnMouseReleased(e -> pt.play());
		
        primaryStage.setTitle("PentagonTrack"); // Set the stage title
        primaryStage.setScene(scene); // Place the scene in the stage
        primaryStage.show(); // Display the stage
        
        // Must request focus after the primary stage is displayed
        polygon.requestFocus();

	}
	public static void main(String[] args) {
		launch(args);
	}
}
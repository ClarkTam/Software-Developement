import javafx.scene.control.RadioButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.paint.Color;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.text.Text;
import javafx.scene.text.*;

public class Exercise16_01 extends Application {

    public static void main(String[] args) {
            launch(args);
    }

    @Override // Override the start method in the Application class
    public void start(Stage primaryStage) {
    Text text = new Text(50, 50, "Programming is fun");
    text.setFont(Font.font("Arial", 24));
    HBox paneForButtons = new HBox(20);
    Button btLeft = new Button("<=");
    Button btRight = new Button("=>");
    paneForButtons.getChildren().addAll(btLeft, btRight);
    paneForButtons.setAlignment(Pos.CENTER);
    paneForButtons.setStyle("-fx-border-color: black");

    BorderPane pane = new BorderPane();
    pane.setBottom(paneForButtons);

    Pane paneForText = new Pane();
    paneForText.getChildren().add(text);
    pane.setCenter(paneForText);

    btLeft.setOnAction(e -> {
        if (text.getX() < 10) {
             text.setX(text.getX() - 0);
        }else{
             text.setX(text.getX() - 10);
        }
    });
    btRight.setOnAction(e -> {
        if (text.getX() > 230) {
             text.setX(text.getX() + 0 );
        }else{
            text.setX(text.getX() + 10);
        }
    });
    

    HBox paneForRadioButtons = new HBox(20);
    paneForRadioButtons.setAlignment(Pos.CENTER);
    paneForRadioButtons.setStyle
    ("-fx-border-width: 1px; -fx-border-color: black");
    RadioButton rbRed = new RadioButton("Red"); 
    RadioButton rbY = new RadioButton("Yellow"); 
    RadioButton rbB = new RadioButton("Black"); 
    RadioButton rbO = new RadioButton("Orange"); 
    RadioButton rbG = new RadioButton("Green"); 
    paneForRadioButtons.getChildren().addAll(rbRed, rbY, rbB, rbO, rbG);
    pane.setTop(paneForRadioButtons);

    ToggleGroup group = new ToggleGroup(); 
    rbRed.setToggleGroup(group); 
    rbY.setToggleGroup(group); 
    rbB.setToggleGroup(group); 
    rbO.setToggleGroup(group); 
    rbG.setToggleGroup(group); 

    rbRed.setOnAction(e -> {
        if (rbRed.isSelected()) {
            text.setFill(Color.RED);
        }
    });
    
    rbY.setOnAction(e -> {
        if (rbY.isSelected()) {
            text.setFill(Color.YELLOW);
        }
    });
    
    rbB.setOnAction(e -> {
        if (rbB.isSelected()) {
            text.setFill(Color.BLACK);
        }
    });

    rbO.setOnAction(e -> {
        if (rbO.isSelected()) {
            text.setFill(Color.ORANGE);
        }
    });

    rbG.setOnAction(e -> {
        if (rbG.isSelected()) {
            text.setFill(Color.GREEN);
        }
    });
    // Create a scene and place it in the stage
    Scene scene = new Scene(pane, 450, 200);
    primaryStage.setTitle("Exericse16_01"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage
    }

        
}

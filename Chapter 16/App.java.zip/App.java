import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import javafx.stage.Stage;
import javafx.scene.media.*;
import javafx.util.Duration;
 
public class App extends Application { 
    int count = 1;

    public static void main(String[] args) {
        launch(args);
    }
    Media media = new Media("https://liveexample.pearsoncmg.com/common/audio/anthem/anthem0.mp3") ;
    MediaPlayer mediaPlayer = new MediaPlayer(media);
    public Timeline animation;
    @Override
    public void start(Stage primaryStage) {
        Pane pane = new Pane();
        primaryStage.setTitle("Exercise16_21");
        primaryStage.setScene(new Scene(pane, 165, 100));
        TextField b = new TextField("");
        b.setFont(Font.font("Arial",55));
        pane.getChildren().add(b);
        primaryStage.show();
        // action event
        b.setOnKeyPressed(e -> {
            if(e.getCode() == KeyCode.ENTER){
                animation.play();
            } 
        });
        
        animation = new Timeline(new KeyFrame(Duration.seconds(1), e -> {
            count = Integer.parseInt(b.getText());
            count--;
            setb(b, count);

            if(count == 0){
                animation.stop();
                mediaPlayer.play();
            }
        }));
            animation.setCycleCount(Timeline.INDEFINITE);
    }

    public void setb(TextField b, int count) {
        String myString = String.valueOf(count);
        b.setText(myString);
        
    }

}
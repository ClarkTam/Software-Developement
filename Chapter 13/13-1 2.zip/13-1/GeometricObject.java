public abstract class GeometricObject {
	private String color = "red";
	private boolean filled;
	
	protected GeometricObject() {
	}
	
	protected GeometricObject(String color, boolean filled) {
		this.color = color;
		this.filled = filled;
	}
	
	public String getColor() {
		return color;
	}
	
	public void setColor(String color) {
		this.color = color;
	}
	
	
	public boolean isFilled() {
		return filled;
	}
	
	public void setFilled(boolean filled) {
		this.filled = filled;
	}
	
	public double getArea(double side1, double side2, double side3, double s) {
		double area = Math.sqrt(s*(s - side1)*(s - side2)*(s - side3) );
		return area;
	}
	
	public double getPerimeter(double side1, double side2, double side3) {
		return side1 + side2 + side2;
		
	}
	
	public String toString() {
		return " color: " + this.getColor() + " filled: " + this.isFilled();
	}
	
	
	
	
}
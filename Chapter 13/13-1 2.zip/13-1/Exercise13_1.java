import java.util.Scanner;
public class Exercise13_1{
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		
		System.out.print("Enter Side 1: ");
		double side1 = input.nextDouble();
		System.out.print("Enter Side 2: ");
		double side2 = input.nextDouble();
		System.out.print("Enter Side 3: ");
		double side3 = input.nextDouble();
		double s = ((side1+side2+side3)/2);
		
		Triangle triangle = new Triangle();
		
		System.out.print("Enter a Color: ");
		String color = input.next();
		triangle.setColor(color);
		System.out.print("Filled?: ");
		Boolean fill = input.nextBoolean();
		triangle.setFilled(fill);
		
		
		
		System.out.println ("Area: " +  triangle.getArea(side1, side2, side3, s) + " Perimeter: " + triangle.getPerimeter(side1, side2, side3));
		System.out.print(triangle.toString());
		
		
	}
}

public class Triangle extends GeometricObject {
	
	Triangle() {
	}
	
	Triangle(double side1, double side2, double side3) {
		
	}
	
	
	
	
	
	
}
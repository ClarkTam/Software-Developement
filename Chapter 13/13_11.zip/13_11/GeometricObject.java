public class GeometricObject {
	double side;
	
	protected GeometricObject() {
	}
	
	protected GeometricObject(Double side) {
		side = side;
	}
	
	public Double getSide(Double side) {
		return side;
	}
	
	public void setSide(Double side) {
		side = side;
	}
	
	public double getArea() {
		return (2+(4/Math.sqrt(2))*side*side);
	}
	
	
	
}
public class Octagon extends GeometricObject
implements Comparable<Octagon>, Cloneable {
	
	Octagon() {
	}
	
	Octagon(double side) {
	}
	
	
	public void clone(Octagon o) {
		Octagon cloneOctagon = o;
	}
	
	
	@Override
	public int compareTo(Octagon o) {
		if (getArea() > o.getArea() ) {
			return 1;
		}else if (getArea() < o.getArea() ) {
			return -1;
		}else {
			return 0;
		}
	}
	
	
	
	
	
}
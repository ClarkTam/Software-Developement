class TEST {
	public static void main(String[] args) {
		
		double side = 3;
		
		Octagon testOctagon = new Octagon();
		
		Octagon cloneOctagon = testOctagon;
		
		System.out.print(testOctagon.compareTo(cloneOctagon));
		
		
	}
}
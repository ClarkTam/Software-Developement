import java.awt.*;

//import java.awt.*;

//import java.awt.*;
public class Rectangle {
	
		static double width = 1;
		static double height = 1;
		
		Rectangle() {
		}
		
		Rectangle(double width, double height) {
			width = width;
			height = height;
		}
	
		public static double getArea(double width, double height) {
			double area = width * height;
			return area;
		}
		
		public static double getPerimeter(double width, double height) {
			double perimeter = (width*2) + (height*2);
			return perimeter;
		}
		
		
	}

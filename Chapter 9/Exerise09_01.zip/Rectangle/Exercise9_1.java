import java.awt.*;

//import java.awt.*;

public class Exercise9_1 {
	public static void main(String[] args) {

	double width = 4;
	double height = 40;
	Rectangle Rectangle1 = new Rectangle(width,height);
	
	System.out.println("Width is " + width);
	System.out.println("Height is " + height);
	System.out.println("Area is " + Rectangle1.getArea(width,height));
	System.out.println("Perimeter is " + Rectangle1.getPerimeter(width,height));
	System.out.println(" ");
	
	
	width = 3.5;
	height = 39.5;
	Rectangle Rectangle2 = new Rectangle(width,height);
	
	System.out.println("Width is " + width);
	System.out.println("Height is " + height);
	System.out.println("Area is " + Rectangle2.getArea(width,height));
	System.out.println("Perimeter is " + Rectangle2.getPerimeter(width,height));
	
	}
}
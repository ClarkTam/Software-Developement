import java.util.Date;

public class Exercise9_7 {
	public static void main(String[] args) {
		int id = 1122;
		double balance = 20000;
		Account account1 = new Account(id,balance);
		Double IntRate = 0.045;
		double monthlyIntRate = account1.getMonthlyInterestRate(IntRate);
		double withdraw = 2500;
		balance = account1.withdraw(withdraw);
		double deposit = 3000;
		balance = account1.deposit(deposit);
		Date date = new Date();
		System.out.println("Balance is: " + balance);
		System.out.println("The Monthly Interest is: " + account1.getMonthlyInterest(monthlyIntRate,balance));
		System.out.println("Account was created on " + account1.dateCreated(date));
		
	}
}
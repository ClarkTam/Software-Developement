import java.util.Scanner;
import java.awt.*;

class ATM {
	public static void main(String[] args) {
		double balance = 100;
		Scanner input = new Scanner(System.in);
		int userid= 0;
		Account[] array = new Account[10];
		for (int i = 0; i < 9; i++) {
			array[i] = new Account();
		}
		
		int start = 1;
		while (start == 1) {
		
			int next = 0;
			while (next == 0) {
				System.out.print("Enter ID: ");
				userid = input.nextInt();
				if (userid >= 0 && userid <= 9) {
					next++;
				}
			}
			runAccount(array, userid, balance);
			
		}
		
	}
	
	
	public static void runAccount(Account[] array, int userid, double balance) {
		Scanner input = new Scanner(System.in);
		
		int end = 0;
		while (end == 0) {
			end = 0;
			System.out.println("Main Menu");
			System.out.println("1: check balance");
			System.out.println("2: withdraw");
			System.out.println("3: deposit");
			System.out.println("4: exit");
			
			System.out.println(" ");
			
			int choicend = 0;
			while (choicend == 0) {
				System.out.println("Enter a choice: ");
				int choice = input.nextInt();
				if (choice == 1) {
					System.out.println("The balance is " + array[userid].getbalance());
				}else if (choice == 2) {
					System.out.println("Enter an amount to withdraw: ");
					double withdraw = input.nextInt();
					array[userid].setbalance(array[userid].withdraw(withdraw));
				}else if (choice == 3) {
					System.out.println("Enter an amount to deposit: ");
					double deposit = input.nextInt();
					balance += deposit;
					array[userid].setbalance(array[userid].deposit(deposit));
				}else if (choice == 4) {
					choicend++;
					end++;
				}else {
					choicend = choicend;
				}
				System.out.println(" ");
			}
		}
		int RESTARTid = 0;
		RESTARTid++;
	}
	
	
}
	
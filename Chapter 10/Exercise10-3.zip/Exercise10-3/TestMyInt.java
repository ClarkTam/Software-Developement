class TestMyInt {
	public static void main(String[] args) {
		int value = 10;
		int svalue = 9;
		
		MyInteger newInt = new MyInteger(svalue);
		
		System.out.println(newInt.isEven(value));
		System.out.println(newInt.isOdd(value));
		System.out.println(newInt.isPrime(value));
		
		System.out.println(newInt.isEven(svalue));
		System.out.println(newInt.isOdd(svalue));
		System.out.println(newInt.isPrime(svalue));
		
		System.out.println(newInt.equals(value));
		System.out.println(newInt.equals(svalue));
		
		char[ ] array1 = {'2', '1', '3', '6', '8'};
		System.out.println(newInt.parseInt(array1));
		
		String string = new String("12345643");
		System.out.println(newInt.parseInt(string));
		
		
	}
}
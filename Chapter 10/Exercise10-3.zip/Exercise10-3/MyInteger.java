import javax.swing.*;

class MyInteger {
	static int value;
	
	MyInteger(int svalue) {
		svalue = svalue;
	}
	
	public int getValue(int value) {
		return value;
	}
	
	public boolean isEven() {
		if (value % 2 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean isOdd() {
		if (value % 2 != 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public boolean isPrime() {
		boolean flag = false;
			// 0 and 1 are not prime numbers
			if (value == 0 || value == 1) {
					flag = true;
			}
			for (int i = 2; i <= value / 2; ++i) {
				// condition for nonprime number
				if (value % i == 0) {
					flag = true;
					break;
				}
			}
		if (!flag) {
			return true;
		}else{
			return false;
		}
	}
	
	
	public static boolean isEven(int svalue) {
		if (svalue % 2 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
		public static boolean isOdd(int svalue) {
		if (svalue % 2 != 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean isPrime(int svalue) {
		boolean flag = false;
			// 0 and 1 are not prime numbers
			if (svalue == 0 || svalue == 1) {
					flag = true;
			}
			for (int i = 2; i <= svalue / 2; ++i) {
				// condition for nonprime number
				if (svalue % i == 0) {
					flag = true;
					break;
				}
			}
		if (!flag) {
			return true;
		}else{
			return false;
		}
	}
	
	
	
	public static boolean isEven(MyInteger svalue) {
		if (svalue.value % 2 == 0) {
			return true;
		}
		else {
			return false;
		}
	}
		public static boolean isOdd(MyInteger svalue) {
		if (svalue.value % 2 != 0) {
			return true;
		}
		else {
			return false;
		}
	}
	
	public static boolean isPrime(MyInteger svalue) {
		boolean flag = false;
			// 0 and 1 are not prime numbers
			if (svalue.value == 0 || svalue.value == 1) {
					flag = true;
			}
			for (int i = 2; i <= svalue.value / 2; ++i) {
				// condition for nonprime number
				if (svalue.value % i == 0) {
					flag = true;
					break;
				}
			}
		if (!flag) {
			return true;
		}else{
			return false;
		}
	}
	
	public boolean equals(int value, MyInteger svalue) {
		if (value != svalue.value) {
			return false;
		}else {
			return true;
		}
	}
	public boolean equals(MyInteger svalue) {
		if (value != svalue.value) {
			return false;
		}else {
			return true;
		}
	}
	
	public static int parseInt(char[] array) {
		int column = array.length;
		int c = 0;
		int number = 0;
		while (c < column) {
			String stringc = String.valueOf(array[c]);
			number += Integer.parseInt(stringc);
			c++;
		}
		return number;
	}
	public static int parseInt(String string) {
		return Integer.parseInt(string);
	}
		

	
}
import java.io.*;

public class MakeExercise17_1 {
	public static void main(String[] args) throws IOException {
		try (FileOutputStream fos = new FileOutputStream("Exercise17_01.txt");
			DataOutputStream output = new DataOutputStream(new BufferedOutputStream(fos))) {
			String string = " ";
				for (int i = 0; i < 100; i++) {
					int num = ((int)(Math.random()*100)+1);
					string = Integer.toString(num);
					output.writeUTF(string + " ");
				}
		}
		catch(Exception ex){
			System.out.println(ex.getMessage());
		}
	}
}
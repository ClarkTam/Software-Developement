import java.util.Scanner;
import java.io.*;


public class Exercise14_15 {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		
		System.out.print("Enter Input File Name: ");
		String Ifilename = scanner.next();
		
		System.out.print("Enter Output File Name: ");
		String Ofilename = scanner.next();
		
		try (
				ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(Ifilename));
		) {

				output.write(5);
		}
		catch (IOException ex) {
			System.out.println("File could not be opened");
		}
		
		

		try (
				ObjectInputStream input = new ObjectInputStream(new FileInputStream(Ifilename));
				ObjectOutputStream output2 = new ObjectOutputStream(new FileOutputStream(Ofilename));
			) {
			
				int newvar = input.readInt();
				newvar -= 5;
				output2.write(newvar);
		}
		catch (IOException ex) {
			System.out.println(" ");
		}
	

	}
}
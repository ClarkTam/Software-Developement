import java.util.Scanner;
import java.util.Date;

public class GeometricObject {
	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		Triangle newTriangle = new Triangle();
		System.out.print("Side 1 = ");
		newTriangle.setside1(input.nextDouble());
		System.out.print("Side 2 = ");
		newTriangle.setside2(input.nextDouble());
		System.out.print("Side 3 = ");
		newTriangle.setside3(input.nextDouble());
		
		
		System.out.print("Color: ");
		String color = input.next();
		System.out.print("Filled?(Answer true or false): ");
		Boolean filledTF = input.nextBoolean();
		String filledQ = "dunno";
		if (filledTF == true) {
			filledQ = "is";
		}else if (filledTF == false) {
			filledQ = "is not";
		}
		Date dateCreated = new Date();
				
		System.out.println(" ");
		System.out.println(" ");
		System.out.println(newTriangle.toString());
		System.out.println("Triangle's area is " + newTriangle.getArea(newTriangle.getside1(), newTriangle.getside2(), newTriangle.getside3())+".");
		System.out.println("Triangle's perimeter is " + newTriangle.getPerimeter(newTriangle.getside1(), newTriangle.getside2(), newTriangle.getside3()) + ".");
		System.out.println("Triangle is " + color + " and it " + filledQ + " filled.");
		System.out.println("Triangle was created "+ dateCreated);
		
		
		
	}
}
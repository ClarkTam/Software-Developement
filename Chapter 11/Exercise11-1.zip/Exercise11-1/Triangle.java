public class Triangle extends GeometricObject {
	
	double side1 = 1.0;
	double side2 = 1.0;
	double side3 = 1.0;
	
	Triangle() {
		
	}
	
	Triangle(double side1, double side2, double side3) {
		
	}
	
	public double getside1() {
		return side1;
	}
	public double getside2() {
		return side2;
	}
	public double getside3() {
		return side3;
	}
	
	public void setside1(double uside1) {
		side1 = uside1;
	}
	public void setside2(double uside2) {
		side2 = uside2;
	}
	public void setside3(double uside3) {
		side3 = uside3;
	}
	
	
	
	public double getArea(double side1, double side2, double side3) {
		double s = ((side1+side2+side3)/2);
		double area = Math.sqrt(s*(s - side1)*(s - side2)*(s - side3));
		return area;
	}
	
	
	public double getPerimeter(double side1, double side2, double side3) {
		double perimeter = (side1 + side2 + side3);
		return perimeter;
	}
	
	
	public String toString() {
		return "Triangle: side1 = " + side1 + " side2 = " + side2 + " side3 = " + side3;
	}
	
	
	
	
}
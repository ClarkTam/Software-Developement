import java.util.Date;

public class Exercise11_3 {
	public static void main(String[] args) {
		
		int id = 1122;
		double balance = 20000;
		double IntRate = 0.045;
		Account account1 = new Account(id,balance);
		System.out.println(account1.toString());
		
		
		id = 3444;
		balance = 100;
		IntRate = 0.05;
		CheckingAccount caccount2 = new CheckingAccount(id,balance);
		System.out.println(caccount2.toString());
		
		
		id = 1550;
		balance = 71000;
		IntRate = 0.07;
		SavingsAccount saccount3 = new SavingsAccount(id,balance);
		System.out.println(saccount3.toString());
		
	}
}
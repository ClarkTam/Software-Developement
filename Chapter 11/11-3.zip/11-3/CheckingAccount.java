public class CheckingAccount extends Account {
	
	CheckingAccount() {
	}
	
	
	CheckingAccount(int newid, double newbalance) {
		this.id = newid;
		this.balance = newbalance;
	}
	
		double withdraw = 0;
	double deposit = 0;
	public double withdraw(double withdraw) {
		if (withdraw > (balance+1000)) {
			System.out.println("Withdrawal higher than overdraft limit($1000)");
			System.out.println("Withdrawal Cancelled");
			return balance;
		}else{
			balance -= withdraw;
			return balance;
		}
	}
	@Override
	public String toString() {
			return "ID = " + id + " balance = " + balance;
	}
}

class SavingsAccount extends Account {
	
	SavingsAccount() {
	}
	
	
	SavingsAccount(int newid, double newbalance) {
		this.id = newid;
		this.balance = newbalance;
	}
	
		double withdraw = 0;
	double deposit = 0;
	public double withdraw(double withdraw) {
		if (withdraw > balance) {
			System.out.println("Withdrawal higher than balance");
			System.out.println("Withdrawal Cancelled");
			return balance;
		}else{
			balance -= withdraw;
			return balance;
		}
	}
	@Override
	public String toString() {
			return "ID = " + id + " balance = " + balance;
	}
}
